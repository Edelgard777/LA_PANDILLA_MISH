package miningtech;

public class Perforadoras extends Maquina implements Cobradora {
    
    private String tipoPerforacion;

    public Perforadoras(String tipoPerforacion, String codigo, String nombre, int potenciaCaballosFuerza, String tipoCombustible, int diasOperativos) {
        super(codigo, nombre, potenciaCaballosFuerza, tipoCombustible, diasOperativos);
        this.tipoPerforacion = tipoPerforacion;
    }
    
    public Perforadoras() {
        // ...
    }

    public String getTipoPerforacion() {
        return tipoPerforacion;
    }

    public void setTipoPerforacion(String tipoPerforacion) {
        this.tipoPerforacion = tipoPerforacion;
    }
    
    @Override
    public double costoFinal() {
        double aumento = 1.00;
        if (tipoPerforacion.equalsIgnoreCase("alta perforacion")) {
            aumento = 1.08;
        }
        return (COSTO_DIA_OPERACION * diasOperativos) * aumento;
    }
    
    @Override
    public void mostrarInfo() {
        System.out.println("Codigo: " + codigo + ", Nombre: " + nombre + ", Potencia caballo de fuerza: " + potenciaCaballosFuerza + ", Tipo de combustible: " + tipoCombustible + ", D�as operativos: " + diasOperativos + ", Tipo de perforaci�n: " + tipoPerforacion);
    }
    
}
