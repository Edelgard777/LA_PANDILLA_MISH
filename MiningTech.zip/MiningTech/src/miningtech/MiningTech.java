package miningtech;

public class MiningTech {

    public static void main(String[] args) {
        GestionDeMaquinas maquinas = new GestionDeMaquinas();
        
        Excavadoras e1 = new Excavadoras("corte", "001", "Nose", 10, "93", 30);
        Excavadoras e2 = new Excavadoras("cuchara", "002", "Abc", 15, "94", 28);
        Excavadoras e3 = new Excavadoras("cucharon", "003", "Efg", 13, "93", 22);
        Camiones c1 = new Camiones("004", "Camn1", 19, "95", 45);
        Camiones c2 = new Camiones("005", "Lol", 18, "93", 30);
        Camiones c3 = new Camiones("006", "Wtf", 21, "93", 32);
        Perforadoras p1 = new Perforadoras("alta perforacion", "007", "Perfff", 17, "94", 25);
        Perforadoras p2 = new Perforadoras("barrenos peque�os", "008", "Ahaha", 20, "94", 21);
        
        maquinas.agregarMaquina(e1);
        maquinas.agregarMaquina(c3);
        maquinas.agregarMaquina(e3);
        maquinas.agregarMaquina(c1);
        maquinas.agregarMaquina(p1);
        maquinas.agregarMaquina(c2);
        maquinas.agregarMaquina(p2);
        maquinas.agregarMaquina(e2);
        
        System.out.println("Lista maquinas (normal)");
        maquinas.listarMaquinas();
        
        System.out.println("Listas maquinas (filtrado)");
        maquinas.filtrarMaquinas();
        
        // Eliminando una maquina
        maquinas.eliminarMaquina(p2);
        maquinas.eliminarMaquina(0);
        
        System.out.println("Desp�es de eliminar dos maquinas (p2 y e1)");
        maquinas.listarMaquinas();
        
    }
    
    /*
    -- ATAJOS --
    ab -> abstract
    db -> double
    pu -> public
    pr -> private
    pe -> protected
    im -> implements
    ex -> extends
    fore -> for (<tipo> i : lista)
    */
    
}
