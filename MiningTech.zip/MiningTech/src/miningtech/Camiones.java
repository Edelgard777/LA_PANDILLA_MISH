package miningtech;

public class Camiones extends Maquina implements Cobradora {
    
    private double capacidadDeCarga;

    public Camiones(String codigo, String nombre, int potenciaCaballosFuerza, String tipoCombustible, int diasOperativos) {
        super(codigo, nombre, potenciaCaballosFuerza, tipoCombustible, diasOperativos);
    }

    public Camiones() {
        // ...
    }

    public double getCapacidadDeCarga() {
        return capacidadDeCarga;
    }

    public void setCapacidadDeCarga(double capacidadDeCarga) {
        this.capacidadDeCarga = capacidadDeCarga;
    }
    
    @Override
    public double costoFinal() {
        double aumento = 1.00;
        if (capacidadDeCarga == 50) {
            aumento = 1.10;
        }
        return (COSTO_DIA_OPERACION * diasOperativos) * aumento;
    }
    
    @Override
    public void mostrarInfo() {
        System.out.println("Codigo: " + codigo + ", Nombre: " + nombre + ", Potencia caballo de fuerza: " + potenciaCaballosFuerza + ", Tipo de combustible: " + tipoCombustible + ", D�as operativos: " + diasOperativos + ", Capacidad de carga (toneladas): " + capacidadDeCarga);
    }
    
}
