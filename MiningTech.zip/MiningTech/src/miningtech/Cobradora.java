package miningtech;

public interface Cobradora {
    
    int COSTO_DIA_OPERACION = 700;
    double costoFinal();
    
}
