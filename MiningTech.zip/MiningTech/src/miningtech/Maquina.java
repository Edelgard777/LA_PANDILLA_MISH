package miningtech;

public abstract class Maquina {
    
    protected String codigo;
    protected String nombre;
    protected int potenciaCaballosFuerza;
    protected String tipoCombustible;
    protected int diasOperativos;

    public Maquina(String codigo, String nombre, int potenciaCaballosFuerza, String tipoCombustible, int diasOperativos) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.potenciaCaballosFuerza = potenciaCaballosFuerza;
        this.tipoCombustible = tipoCombustible;
        this.diasOperativos = diasOperativos;
    }

    public Maquina() {
        // ...
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getPotenciaCaballosFuerza() {
        return potenciaCaballosFuerza;
    }

    public void setPotenciaCaballosFuerza(int potenciaCaballosFuerza) {
        this.potenciaCaballosFuerza = potenciaCaballosFuerza;
    }

    public String getTipoCombustible() {
        return tipoCombustible;
    }

    public void setTipoCombustible(String tipoCombustible) {
        this.tipoCombustible = tipoCombustible;
    }

    public int getDiasOperativos() {
        return diasOperativos;
    }

    public void setDiasOperativos(int diasOperativos) {
        this.diasOperativos = diasOperativos;
    }
    
    public void mostrarInfo() {
        System.out.println("Codigo: " + codigo + ", Nombre: " + nombre + ", Potencia caballo de fuerza: " + potenciaCaballosFuerza + ", Tipo de combustible: " + tipoCombustible + ", D�as operativos: " + diasOperativos);
    }
    
}
