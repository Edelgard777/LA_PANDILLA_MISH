package miningtech;

public class Excavadoras extends Maquina implements Cobradora {
    
    private String tipoCuchara;

    public Excavadoras(String tipoCuchara, String codigo, String nombre, int potenciaCaballosFuerza, String tipoCombustible, int diasOperativos) {
        super(codigo, nombre, potenciaCaballosFuerza, tipoCombustible, diasOperativos);
        this.tipoCuchara = tipoCuchara;
    }

    public Excavadoras() {
        // ...
    }

    public String getTipoCuchara() {
        return tipoCuchara;
    }

    public void setTipoCuchara(String tipoCuchara) {
        this.tipoCuchara = tipoCuchara;
    }
    
    @Override
    public double costoFinal() {
        double aumento = 1.00;
        if (tipoCuchara.equalsIgnoreCase("corte")) {
            aumento = 1.12;
        }
        return (COSTO_DIA_OPERACION * diasOperativos) * aumento;
    }
    
    @Override
    public void mostrarInfo() {
        System.out.println("Codigo: " + codigo + ", Nombre: " + nombre + ", Potencia caballo de fuerza: " + potenciaCaballosFuerza + ", Tipo de combustible: " + tipoCombustible + ", D�as operativos: " + diasOperativos + ", Tipo de cuchara: " + tipoCuchara);
    }
    
}
