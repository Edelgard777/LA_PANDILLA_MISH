package miningtech;

import java.util.ArrayList;

public class GestionDeMaquinas {
    
    private ArrayList<Maquina> maquinas = new ArrayList();

    public GestionDeMaquinas() {
        // ...
    }
    
    public void agregarMaquina(Maquina maquina) {
        // for (<tipo> i : lista)
        for (Maquina m : maquinas) {
            if (m.getCodigo().equalsIgnoreCase(maquina.getCodigo())) {
                System.out.println("Ya existe la maquina");
                return;
            }
        }
        this.maquinas.add(maquina);
    }
    
    public void listarMaquinas() {
        if (maquinas.isEmpty()) {
            System.out.println("No hay maquinas registradas");
            return;
        }
        for (Maquina m : maquinas) {
            m.mostrarInfo();
        }
    }
    
    public void filtrarMaquinas() {
        if (maquinas.isEmpty()) {
            System.out.println("No hay maquinas registradas");
            return;
        }
        for (Maquina m : maquinas) {
            if (m instanceof Excavadoras) {
                m.mostrarInfo();
            }
        }
        for (Maquina m : maquinas) {
            if (m instanceof Camiones) {
                m.mostrarInfo();
            }
        }
        for (Maquina m : maquinas) {
            if (m instanceof Perforadoras) {
                m.mostrarInfo();
            }
        }
    }
    
    public void eliminarMaquina(Maquina o) {
        this.maquinas.remove(o);
    }
    
    public void eliminarMaquina(int indice) {
        this.maquinas.remove(indice);
    }
    
}
