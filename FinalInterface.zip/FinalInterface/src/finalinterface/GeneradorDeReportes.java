/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package finalinterface;

/**
 *
 * @author vina
 */
//crea un metodo para traer al reporte 
public final class GeneradorDeReportes{
  public void generarReporte(String idTransaccion){
      System.out.println("**** REPORTE FINANCIERO FINAL****");
      System.out.println("ID de transaccion: " + idTransaccion);
      System.out.println("Estado: COMPLETADO");
      System.out.println("¨*******");
      
  }
  //implementacion obligatorio del metodo de la interfaz
  public void enviarNotificacion(String mensaje ){
      System.out.println("Reporte del sistema:"  + mensaje);
      
  }
      
  
  
}
