/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package finalinterface;

/**
 *
 * @author vina
 */
//superclase
public class ProcesadordePago implements Notificable{
    //metodo que sobreescribe las clases 
    public void realizarPago(){
        System.out.println("Realizando pago generico...");
        
    }
    // metodo final: ninguna clase puede cambiar su comportamiento 
    public final void validarTransaccion(){
        System.out.println("VALIDACION DE SEGURIDAD: conectando a los servidores");
    }
    
    //implementacion obligatoria del metodo de la interfaz
    @Override
    public void enviarNotificacion(String mensaje){
        System.out.println("NOTIFICACION GENERAL: " + mensaje);
    }
}
