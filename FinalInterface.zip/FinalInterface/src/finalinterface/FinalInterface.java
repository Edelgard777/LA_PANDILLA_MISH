/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package finalinterface;

/**
 *
 * @author vina
 */
public class FinalInterface {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("***iniciando una transaccion con PayPal");
        
        //creamos un objeto de la subclase
        PagoPayPal miPago = new PagoPayPal();
        
        //llamamos al metodo final heredado
        miPago.validarTransaccion();
        
        //llamamos el etodo sobreescrito de la subclase 
        miPago.realizarPago();
        
        // llamamos al metodo de la interfaz
        miPago.enviarNotificacion("Tu pago de $80.000 a sido exitoso ");
        
        System.out.println("Generando el reporte final");
        
        //creamos un objeto de la clase final 
        GeneradorDeReportes reporte = new GeneradorDeReportes();
        reporte.generarReporte("GHJ-987-QWE");
        
        //llamamos al metodo de la interfaz, pero iplementado en otra clase 
        reporte.enviarNotificacion("Se a generado un nuevo reporte");
        
                
    }
    
}
