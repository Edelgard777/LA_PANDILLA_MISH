/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package finalinterface;

/**
 *
 * @author vina
 */
public interface Notificable {
    //por defecto, este metodo es "public" y "abstract"
    
    void enviarNotificacion(String mensaje);
    
}
