/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package finalinterface;

/**
 *
 * @author vina
 */
//subclase palabra reservada extends
public class PagoPayPal extends ProcesadordePago {
    //sobreescribe el metodo de la superclase
    @Override
    public void realizarPago(){
        System.out.println("Procesando pago desde PayPal");
    }
    
    // sobreescribir el metodo de la interfaz
    @Override
    public void enviarNotificacion(String mensaje){
        System.out.println("EMAIL de PayPal: enviando notificacion");
    }
}
