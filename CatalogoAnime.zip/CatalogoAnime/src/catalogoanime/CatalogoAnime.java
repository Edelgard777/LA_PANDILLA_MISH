/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package catalogoanime;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author vina
 */
public class CatalogoAnime {

    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Anime>catalogo = new ArrayList<>();
        catalogo.add(new SerieTV(88, "Attack on Titan", "WIT", 2010));
        catalogo.add(new Pelicula(110, "Demons Slayer", "Ufotable", 2025));
        
        
        
        int opcion;
        
        do {
            System.out.println("\n -----Catalogo Anime------");
            System.out.println("1.- Agregar Serie de TV");
            System.out.println("2.- Agregar Pelicula");
            System.out.println("3.- Mostrar Catálogo");
            System.out.println("4.- Actualizar Estudio");
            System.out.println("5.- Eliminar Anime");
            System.out.println("6.- Salir");
            System.out.println("Elige una opcion: ");
            opcion = sc.nextInt();
            sc.nextLine();
            
            
            switch(opcion) {
                
                case 1:
                    System.out.println("Titulo: ");
                    String tituloSerie = sc.nextLine();
                    System.out.println("Año: ");
                    int year = sc.nextInt();
                    System.out.println("Estudio: ");
                    String estudioSerie = sc.nextLine();
                    System.out.println("Numero de episodios: ");
                    int eps = sc.nextInt();
                    catalogo.add(new SerieTV(opcion, tituloSerie, estudioSerie, year))
                    
                case 2:
                    
                case 3:
                    
                case 4:
                    
                case 5:
                case 6:
                    
                    
                }
        }
        }
        
        }
    



