package figurasgeometricas;

// ¿Por qué Java tiene que ser tan tradicional que tienes que importar una libreria para elevar numeros?
import java.lang.Math;

public class Circulo extends Figura {
    
    // Segun las diapositivas, un atributo tipo final sirve para indicar que no pueden modificarse
    // una vez que se inicializan, es decir, representan valores constantes.
    
    // La guía no espicifica ningun atributo de tipo final, pero como es el valor de pi, pense que era apropiado declararlo.
    private final double pi = 3.1416;
    
    private double radio;

    public Circulo(double radio, String nombre) {
        super(nombre);
        this.radio = radio;
    }
    
    // Los atributos tipos finales no pueden tener setter, solo getter
    public double getPi() {
        return pi;
    }

    public double getRadio() {
        return radio;
    }

    public void setRadio(double radio) {
        this.radio = radio;
    } 
    
    @Override
    public double perimetro() {
        return 2 * pi * radio;
    }
    
    @Override
    public double area() {
        return pi * Math.pow(radio, 2); // pi * radio^2
    }
    
    @Override
    public void imprimir() {
        System.out.println("Figura: " + nombre + ", Pi: " + pi + ", Radio: " + radio);
    }
    
}
