package figurasgeometricas;

public class Cuadrado extends Figura {
    
    private double largoLados;

    public Cuadrado(double largoLados, String nombre) {
        super(nombre);
        this.largoLados = largoLados;
    }

    public double getLargoLados() {
        return largoLados;
    }

    public void setLargoLados(double largoLados) {
        this.largoLados = largoLados;
    }
    
    @Override
    public double perimetro() {
        return largoLados * 4;
    }
    
    @Override
    public double area() {
        return largoLados * largoLados;
    }
    
    @Override
    public void imprimir() {
        System.out.println("Figura: " + nombre + ", Largo lados: " + largoLados);
    }
    
}
