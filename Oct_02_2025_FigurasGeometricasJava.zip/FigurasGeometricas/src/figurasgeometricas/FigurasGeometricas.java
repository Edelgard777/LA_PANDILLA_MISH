package figurasgeometricas;

public class FigurasGeometricas {

    public static void main(String[] args) {
        // El motoquero callampin bombin
    }
    
}
