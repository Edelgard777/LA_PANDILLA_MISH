package figurasgeometricas;

// Recordar que no se pueden crear objetos de clase abstractas
public abstract class Figura {
    
    protected String nombre;

    public Figura(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    // Los cuerpos de los metodos abstractos se definen despues en las subclases
    public abstract double perimetro();
    public abstract double area();
    
    // El ayudante no lo definio como abstracto pero... ¯\_(ツ)_/¯
    public abstract void imprimir();
    
}
