package figurasgeometricas;

public class Rectangulo extends Figura {

    private double largo;
    private double alto;

    public Rectangulo(double largo, double alto, String nombre) {
        super(nombre);
        this.largo = largo;
        this.alto = alto;
    }

    public double getLargo() {
        return largo;
    }

    public void setLargo(double largo) {
        this.largo = largo;
    }

    public double getAlto() {
        return alto;
    }

    public void setAlto(double alto) {
        this.alto = alto;
    }
    
    @Override
    public double perimetro() {
        return 2 * (largo * alto);
    }
    
    @Override
    public double area() {
        return largo * alto;
    }
    
    @Override
    public void imprimir() {
        System.out.println("Figura: " + nombre + ", Largo: " + largo + ", Alto: " + alto);
    }

}
